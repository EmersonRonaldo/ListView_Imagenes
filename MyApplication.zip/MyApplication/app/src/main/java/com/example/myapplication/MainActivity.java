package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.myapplication.adapters.ProductAdapter;
import com.example.myapplication.helpers.QueueUtils;
import com.example.myapplication.models.Products;

public class MainActivity extends AppCompatActivity {
    QueueUtils.QueueObject queue = null;
    ProductAdapter productAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        queue = QueueUtils.getInstance(this.getApplicationContext());

        productAdapter =
                new ProductAdapter(this, Products.getData(), queue.getImageLoader());
    }
}
