package com.example.myapplication.models;

import java.util.ArrayList;

public class Products {
    public String name;
    public String description;
    public String imagen;

    public Products (String _name, String _desc, String _image) {
        this.name = _name;
        this.description = _desc;
        this.imagen = _image;
    }

    public String toString() {
        return this.name;
    }

    public static ArrayList<Products> getData() {
        ArrayList<Products> products = new ArrayList<>();
        products.add(new Products("Calzado",
                "Zapatilla de fútbol",
                "https://mymodernmet.com/wp/wp-content/uploads/2019/03/adidas-parley-shoes-apparel-7.jpg"));

        products.add(new Products("Calzado",
                "Zapatilla elegante",
                "https://mymodernmet.com/wp/wp-content/uploads/2019/03/adidas-parley-shoes-apparel-6.png"));

        products.add(new Products("Calzado",
                "Balerina plana",
                "https://mymodernmet.com/wp/wp-content/uploads/2019/03/adidas-parley-shoes-apparel-5.jpg"
                        ));

        products.add(new Products("Calzado",
                "Zapatilla juvenil",
                "https://mymodernmet.com/wp/wp-content/uploads/archive/PXEo3FcE1L7vgUxtjVOS_adidasparley2.jpg"));

        return products;
    }

    public String getSmallImage() {
        return this.imagen;
    }
}
